import { GoogleGenAI } from "@google/genai";
import { WorkoutRequest } from '../types';

const getAiClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.warn("API_KEY is missing. AI features will be simulated or fail.");
  }
  return new GoogleGenAI({ apiKey: apiKey || 'dummy-key' });
};

export const generateWorkoutPlan = async (request: WorkoutRequest): Promise<string> => {
  try {
    const ai = getAiClient();
    
    const prompt = `
      You are an elite fitness coach. Create a concise, high-intensity weekly workout plan for a client with the following details:
      - Goal: ${request.goal}
      - Experience Level: ${request.level}
      - Days per week available: ${request.days}

      Format the response as a clean, easy-to-read list using Markdown. 
      Focus on the exercises, sets, and reps. Add a short motivational quote at the end.
      Do not include intro fluff.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 0 } // Speed over deep reasoning for this task
      }
    });

    return response.text || "Failed to generate workout. Please try again.";
  } catch (error) {
    console.error("Error generating workout:", error);
    return "Our AI coach is currently spotting someone else (Service Unavailable). Please try again later.";
  }
};