import React from 'react';
import { Dumbbell, Instagram, Twitter, Facebook, Mail, MapPin, Phone } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-black border-t border-dark-800 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          
          <div className="col-span-1 md:col-span-1">
            <div className="flex items-center space-x-2 mb-6">
              <Dumbbell className="h-6 w-6 text-brand" />
              <span className="font-display font-bold text-xl tracking-tighter text-white">
                GYM<span className="text-brand">JUNKIES</span>
              </span>
            </div>
            <p className="text-gray-500 text-sm leading-relaxed mb-6">
              Forging elite fitness since 2015. We provide the atmosphere, equipment, and guidance you need to destroy your limits.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-brand transition-colors"><Instagram className="h-5 w-5" /></a>
              <a href="#" className="text-gray-400 hover:text-brand transition-colors"><Twitter className="h-5 w-5" /></a>
              <a href="#" className="text-gray-400 hover:text-brand transition-colors"><Facebook className="h-5 w-5" /></a>
            </div>
          </div>

          <div>
            <h4 className="text-white font-bold uppercase tracking-wider mb-6">Quick Links</h4>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-500 hover:text-brand transition-colors text-sm">About Us</a></li>
              <li><a href="#" className="text-gray-500 hover:text-brand transition-colors text-sm">Classes</a></li>
              <li><a href="#" className="text-gray-500 hover:text-brand transition-colors text-sm">Trainers</a></li>
              <li><a href="#" className="text-gray-500 hover:text-brand transition-colors text-sm">Membership</a></li>
              <li><a href="#" className="text-gray-500 hover:text-brand transition-colors text-sm">Merch Store</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold uppercase tracking-wider mb-6">Support</h4>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-500 hover:text-brand transition-colors text-sm">FAQ</a></li>
              <li><a href="#" className="text-gray-500 hover:text-brand transition-colors text-sm">Contact Support</a></li>
              <li><a href="#" className="text-gray-500 hover:text-brand transition-colors text-sm">Privacy Policy</a></li>
              <li><a href="#" className="text-gray-500 hover:text-brand transition-colors text-sm">Terms of Service</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold uppercase tracking-wider mb-6">Contact</h4>
            <ul className="space-y-4">
              <li className="flex items-start">
                <MapPin className="h-5 w-5 text-brand shrink-0 mr-3" />
                <span className="text-gray-500 text-sm">123 Iron Paradise Blvd, Muscle City, CA 90210</span>
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 text-brand shrink-0 mr-3" />
                <span className="text-gray-500 text-sm">+1 (555) 420-6969</span>
              </li>
              <li className="flex items-center">
                <Mail className="h-5 w-5 text-brand shrink-0 mr-3" />
                <span className="text-gray-500 text-sm">join@gymjunkies.com</span>
              </li>
            </ul>
          </div>

        </div>

        <div className="border-t border-dark-800 pt-8 text-center">
          <p className="text-gray-600 text-sm">
            © {new Date().getFullYear()} Gym Junkies. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};