import React from 'react';
import { Button } from './Button';
import { ChevronRight } from 'lucide-react';

export const Hero: React.FC = () => {
  return (
    <div className="relative h-screen min-h-[600px] flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.pexels.com/photos/1954524/pexels-photo-1954524.jpeg" 
          alt="Gym Interior" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-dark-900 via-dark-900/80 to-dark-900/40"></div>
        <div className="absolute inset-0 bg-black/20"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center sm:text-left w-full mt-16">
        <div className="sm:max-w-2xl">
          <div className="inline-flex items-center rounded-full border border-brand/30 bg-brand/10 px-3 py-1 text-sm text-brand mb-6 backdrop-blur-sm">
            <span className="flex h-2 w-2 rounded-full bg-brand mr-2 animate-pulse"></span>
            Now Open 24/7 in Downtown
          </div>
          
          <h1 className="text-5xl sm:text-7xl font-display font-bold text-white tracking-tight leading-tight mb-6">
            FORGE YOUR <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand to-brand-light">ULTIMATE FORM</span>
          </h1>
          
          <p className="mt-4 text-xl text-gray-300 mb-8 max-w-lg leading-relaxed">
            Stop making excuses. Start making history. Join the community dedicated to pushing limits and breaking barriers.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <Button className="group">
              Start Free Trial
              <ChevronRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button variant="secondary">
              View Class Schedule
            </Button>
          </div>
        </div>
      </div>

      {/* Scrolling text banner */}
      <div className="absolute bottom-0 left-0 right-0 bg-brand text-black py-3 overflow-hidden whitespace-nowrap z-10 border-t border-brand-light">
         <div className="flex items-center scrolling-text font-display font-bold text-lg tracking-widest uppercase">
            <span className="mx-4">Build Muscle</span> • 
            <span className="mx-4">Lose Fat</span> • 
            <span className="mx-4">Gain Confidence</span> • 
            <span className="mx-4">Expert Trainers</span> • 
            <span className="mx-4">State of the Art</span> •
            <span className="mx-4">Open 24/7</span> •
            <span className="mx-4">Free Weights</span> • 
            <span className="mx-4">Cardio Theater</span> • 
            <span className="mx-4">Sauna & Steam</span> •
            <span className="mx-4">Build Muscle</span> • 
            <span className="mx-4">Lose Fat</span> • 
            <span className="mx-4">Gain Confidence</span> • 
            <span className="mx-4">Expert Trainers</span> • 
            <span className="mx-4">State of the Art</span> •
            <span className="mx-4">Open 24/7</span> •
            <span className="mx-4">Free Weights</span> • 
            <span className="mx-4">Cardio Theater</span> • 
            <span className="mx-4">Sauna & Steam</span>
         </div>
      </div>
    </div>
  );
};