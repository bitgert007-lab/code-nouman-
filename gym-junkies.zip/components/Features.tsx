import React from 'react';
import { Dumbbell, Clock, Users, Zap, HeartPulse, Trophy } from 'lucide-react';

const features = [
  {
    icon: <Dumbbell className="h-6 w-6" />,
    title: "Premium Equipment",
    description: "Train with the best. Hammer Strength, Eleiko, and Rogue equipment for serious lifters."
  },
  {
    icon: <Clock className="h-6 w-6" />,
    title: "24/7 Access",
    description: "Your schedule shouldn't dictate your gains. Access the facility anytime, day or night."
  },
  {
    icon: <Users className="h-6 w-6" />,
    title: "Expert Community",
    description: "Surround yourself with motivated individuals and certified trainers who push you further."
  },
  {
    icon: <Zap className="h-6 w-6" />,
    title: "HIIT Zones",
    description: "Dedicated turf areas for sled pushes, plyometrics, and high-intensity functional training."
  },
  {
    icon: <HeartPulse className="h-6 w-6" />,
    title: "Recovery Studio",
    description: "Post-workout care with infrared saunas, cryotherapy, and massage guns available."
  },
  {
    icon: <Trophy className="h-6 w-6" />,
    title: "Competitions",
    description: "Monthly powerlifting and fitness challenges to test your progress against the best."
  }
];

export const Features: React.FC = () => {
  return (
    <section id="features" className="py-24 bg-dark-900 relative scroll-mt-24">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gray-800 to-transparent"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-brand font-bold tracking-wider uppercase text-sm mb-2">Why Choose Us</h2>
          <h3 className="text-3xl md:text-5xl font-display font-bold text-white">BUILT FOR THE <span className="text-brand">OBSESSED</span></h3>
          <p className="mt-4 text-gray-400 max-w-2xl mx-auto">
            We're not just a room with weights. We're a sanctuary for those who refuse to be average.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="p-8 rounded-xl bg-dark-800 border border-white/5 hover:border-brand/50 transition-all duration-300 hover:-translate-y-1 group"
            >
              <div className="w-12 h-12 rounded-lg bg-dark-700 flex items-center justify-center text-brand mb-6 group-hover:bg-brand group-hover:text-black transition-colors">
                {feature.icon}
              </div>
              <h4 className="text-xl font-bold text-white mb-3 font-display uppercase">{feature.title}</h4>
              <p className="text-gray-400 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};