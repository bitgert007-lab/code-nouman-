import React from 'react';
import { Check } from 'lucide-react';
import { Button } from './Button';
import { PricingTier } from '../types';

const tiers: PricingTier[] = [
  {
    name: "Day Pass",
    price: "$15",
    features: [
      "Full gym access for 24 hours",
      "Locker room access",
      "Free towel service"
    ],
    recommended: false
  },
  {
    name: "Monthly Elite",
    price: "$59",
    features: [
      "24/7 Keycard Access",
      "Unlimited Classes",
      "1 Personal Training Session",
      "Guest Privileges (Weekends)",
      "Access to all locations"
    ],
    recommended: true
  },
  {
    name: "Annual Pro",
    price: "$499",
    features: [
      "All Monthly Elite perks",
      "2 months free (Save $200)",
      "Gym Junkies Hoodie",
      "Priority Class Booking",
      "Nutrition Consultation"
    ],
    recommended: false
  }
];

export const Pricing: React.FC = () => {
  return (
    <section id="pricing" className="py-24 bg-dark-900 scroll-mt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-brand font-bold tracking-wider uppercase text-sm mb-2">Membership</h2>
          <h3 className="text-4xl font-display font-bold text-white">INVEST IN <span className="text-brand">YOURSELF</span></h3>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {tiers.map((tier, index) => (
            <div 
              key={index} 
              className={`relative flex flex-col p-8 rounded-2xl ${
                tier.recommended 
                  ? 'bg-dark-800 border-2 border-brand shadow-[0_0_30px_rgba(163,230,53,0.15)] transform md:-translate-y-4' 
                  : 'bg-dark-900 border border-dark-700'
              }`}
            >
              {tier.recommended && (
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-brand text-black font-bold text-xs px-4 py-1 rounded-full uppercase tracking-wider">
                  Most Popular
                </div>
              )}
              
              <div className="mb-6">
                <h4 className="text-lg font-medium text-gray-400 uppercase tracking-wide">{tier.name}</h4>
                <div className="mt-4 flex items-baseline text-white">
                  <span className="text-5xl font-display font-bold tracking-tight">{tier.price}</span>
                  {tier.name !== "Day Pass" && <span className="ml-1 text-xl text-gray-500">/mo</span>}
                </div>
              </div>

              <ul className="space-y-4 mb-8 flex-1">
                {tier.features.map((feature, i) => (
                  <li key={i} className="flex items-start">
                    <Check className="h-5 w-5 text-brand shrink-0 mr-3" />
                    <span className="text-gray-300 text-sm">{feature}</span>
                  </li>
                ))}
              </ul>

              <Button 
                variant={tier.recommended ? 'primary' : 'outline'} 
                fullWidth
              >
                Choose Plan
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};