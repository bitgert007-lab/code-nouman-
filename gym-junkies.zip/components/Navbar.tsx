import React, { useState } from 'react';
import { Menu, X, Dumbbell } from 'lucide-react';
import { Button } from './Button';

export const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 w-full z-50 bg-dark-900/90 backdrop-blur-md border-b border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center space-x-2">
            <Dumbbell className="h-8 w-8 text-brand" />
            <span className="font-display font-bold text-2xl tracking-tighter text-white">
              GYM<span className="text-brand">JUNKIES</span>
            </span>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              <a href="#features" className="text-gray-300 hover:text-brand px-3 py-2 rounded-md text-sm font-medium transition-colors">Facilities</a>
              <a href="#classes" className="text-gray-300 hover:text-brand px-3 py-2 rounded-md text-sm font-medium transition-colors">Classes</a>
              <a href="#ai-coach" className="text-brand hover:text-brand-light px-3 py-2 rounded-md text-sm font-medium transition-colors flex items-center gap-1">
                <span className="relative flex h-2 w-2 mr-1">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-brand"></span>
                </span>
                AI Coach
              </a>
              <a href="#pricing" className="text-gray-300 hover:text-brand px-3 py-2 rounded-md text-sm font-medium transition-colors">Membership</a>
            </div>
          </div>

          {/* CTA */}
          <div className="hidden md:block">
            <Button variant="outline" className="text-sm py-2 px-4">
              Join Now
            </Button>
          </div>

          {/* Mobile menu button */}
          <div className="-mr-2 flex md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-dark-700 focus:outline-none"
            >
              {isOpen ? <X className="block h-6 w-6" /> : <Menu className="block h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-dark-900 border-b border-white/10">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <a href="#features" className="text-gray-300 hover:text-brand block px-3 py-2 rounded-md text-base font-medium">Facilities</a>
            <a href="#classes" className="text-gray-300 hover:text-brand block px-3 py-2 rounded-md text-base font-medium">Classes</a>
            <a href="#ai-coach" className="text-brand block px-3 py-2 rounded-md text-base font-medium">AI Coach</a>
            <a href="#pricing" className="text-gray-300 hover:text-brand block px-3 py-2 rounded-md text-base font-medium">Membership</a>
            <div className="pt-4">
               <Button fullWidth>Join Now</Button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};