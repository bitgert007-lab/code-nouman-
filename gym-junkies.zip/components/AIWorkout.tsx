import React, { useState } from 'react';
import { generateWorkoutPlan } from '../services/geminiService';
import { Button } from './Button';
import { FitnessLevel, WorkoutRequest } from '../types';
import { Sparkles, Loader2, Clipboard } from 'lucide-react';

export const AIWorkout: React.FC = () => {
  const [goal, setGoal] = useState('');
  const [level, setLevel] = useState<string>(FitnessLevel.Intermediate);
  const [days, setDays] = useState('3');
  const [loading, setLoading] = useState(false);
  const [plan, setPlan] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!goal) return;
    
    setLoading(true);
    setPlan(null);
    
    const request: WorkoutRequest = { goal, level, days };
    const result = await generateWorkoutPlan(request);
    
    setPlan(result);
    setLoading(false);
  };

  return (
    <section id="ai-coach" className="py-24 bg-dark-800 relative overflow-hidden scroll-mt-24">
      {/* Background Decor */}
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-brand/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-96 h-96 bg-brand/5 rounded-full blur-3xl"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-start">
          
          {/* Left Column: Text & Form */}
          <div>
            <div className="flex items-center gap-2 mb-4">
               <Sparkles className="text-brand h-6 w-6" />
               <span className="text-brand font-bold tracking-wider uppercase text-sm">Powered by Gemini AI</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-display font-bold text-white mb-6">
              YOUR PERSONAL <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand to-white">AI COACH</span>
            </h2>
            <p className="text-gray-400 mb-8 text-lg">
              Not sure where to start? Tell our AI coach your goals, and get a custom weekly plan instantly. No generic PDFs, just pure gains customized for you.
            </p>

            <form onSubmit={handleSubmit} className="space-y-6 bg-dark-900/50 p-8 rounded-2xl border border-white/5 backdrop-blur-sm">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">What is your main goal?</label>
                <input 
                  type="text" 
                  value={goal}
                  onChange={(e) => setGoal(e.target.value)}
                  placeholder="e.g. Build bigger chest, Run 5k, Lose belly fat"
                  className="w-full px-4 py-3 bg-dark-800 border border-dark-600 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-brand focus:border-transparent outline-none transition-all"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Experience Level</label>
                  <select 
                    value={level}
                    onChange={(e) => setLevel(e.target.value)}
                    className="w-full px-4 py-3 bg-dark-800 border border-dark-600 rounded-lg text-white focus:ring-2 focus:ring-brand focus:border-transparent outline-none"
                  >
                    <option value={FitnessLevel.Beginner}>Beginner</option>
                    <option value={FitnessLevel.Intermediate}>Intermediate</option>
                    <option value={FitnessLevel.Advanced}>Advanced</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Days / Week</label>
                  <select 
                    value={days}
                    onChange={(e) => setDays(e.target.value)}
                    className="w-full px-4 py-3 bg-dark-800 border border-dark-600 rounded-lg text-white focus:ring-2 focus:ring-brand focus:border-transparent outline-none"
                  >
                    <option value="1">1 Day</option>
                    <option value="2">2 Days</option>
                    <option value="3">3 Days</option>
                    <option value="4">4 Days</option>
                    <option value="5">5 Days</option>
                    <option value="6">6 Days</option>
                  </select>
                </div>
              </div>

              <Button 
                type="submit" 
                fullWidth 
                disabled={loading}
                className="mt-4"
              >
                {loading ? (
                  <span className="flex items-center">
                    <Loader2 className="animate-spin -ml-1 mr-2 h-5 w-5" />
                    Generating Plan...
                  </span>
                ) : (
                  "Generate Workout Plan"
                )}
              </Button>
            </form>
          </div>

          {/* Right Column: Result Display */}
          <div className="lg:h-[600px] flex flex-col">
            {plan ? (
              <div className="bg-white text-dark-900 rounded-2xl p-8 shadow-2xl h-full overflow-y-auto border border-brand/20 relative">
                <div className="absolute top-0 left-0 w-full h-2 bg-brand"></div>
                <div className="flex justify-between items-center mb-6 pb-6 border-b border-gray-100">
                  <div>
                    <h3 className="text-2xl font-display font-bold uppercase tracking-tight">Your Custom Plan</h3>
                    <p className="text-gray-500 text-sm">Generated for {level} • {days} days/week</p>
                  </div>
                  <Clipboard className="text-gray-400 h-6 w-6 cursor-pointer hover:text-brand transition-colors" />
                </div>
                <div className="prose prose-sm max-w-none prose-headings:font-display prose-headings:uppercase prose-strong:text-brand-dark">
                  <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed text-gray-700">
                    {plan}
                  </pre>
                </div>
              </div>
            ) : (
              <div className="h-full rounded-2xl border-2 border-dashed border-dark-600 flex items-center justify-center p-12 text-center bg-dark-900/30">
                <div className="max-w-xs">
                  <div className="w-16 h-16 bg-dark-700 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Sparkles className="h-8 w-8 text-gray-500" />
                  </div>
                  <h4 className="text-xl font-bold text-white mb-2">Ready to Grind?</h4>
                  <p className="text-gray-400">Fill out the form to let our AI design your perfect week of training.</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};