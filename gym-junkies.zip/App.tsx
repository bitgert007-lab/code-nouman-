import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Features } from './components/Features';
import { AIWorkout } from './components/AIWorkout';
import { Pricing } from './components/Pricing';
import { Footer } from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="bg-dark-900 min-h-screen text-gray-100 font-sans selection:bg-brand selection:text-black">
      <Navbar />
      <main>
        <Hero />
        <Features />
        <AIWorkout />
        <Pricing />
        
        {/* Gallery / Vibe Section */}
        <section className="py-0 overflow-hidden">
          <div className="grid grid-cols-2 md:grid-cols-4 h-64 md:h-80">
            <div className="relative group overflow-hidden">
              <img src="https://images.unsplash.com/photo-1571902943202-507ec2618e8f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" alt="Gym" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
              <div className="absolute inset-0 bg-brand/0 group-hover:bg-brand/20 transition-colors duration-300"></div>
            </div>
            <div className="relative group overflow-hidden">
              <img src="https://images.unsplash.com/photo-1540497077202-7c8a3999166f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" alt="Weights" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
              <div className="absolute inset-0 bg-brand/0 group-hover:bg-brand/20 transition-colors duration-300"></div>
            </div>
            <div className="relative group overflow-hidden">
              <img src="https://images.unsplash.com/photo-1599058945522-28d584b6f0ff?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" alt="Workout" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
              <div className="absolute inset-0 bg-brand/0 group-hover:bg-brand/20 transition-colors duration-300"></div>
            </div>
            <div className="relative group overflow-hidden">
              <img src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" alt="Cardio" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
              <div className="absolute inset-0 bg-brand/0 group-hover:bg-brand/20 transition-colors duration-300"></div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default App;