export interface PricingTier {
  name: string;
  price: string;
  features: string[];
  recommended?: boolean;
}

export interface Testimonial {
  name: string;
  role: string;
  quote: string;
  image: string;
}

export interface WorkoutRequest {
  goal: string;
  level: string;
  days: string;
}

export enum FitnessLevel {
  Beginner = "Beginner",
  Intermediate = "Intermediate",
  Advanced = "Advanced"
}
